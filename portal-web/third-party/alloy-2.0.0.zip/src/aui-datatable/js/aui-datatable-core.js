A.DataTable.NAME = 'table';
A.DataTable.CSS_PREFIX = 'table';
